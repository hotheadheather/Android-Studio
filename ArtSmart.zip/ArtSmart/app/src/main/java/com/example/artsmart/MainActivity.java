
package com.example.artsmart;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    private ImageView mImageView;
    private TextView mTextView;
    private Button mButton;
    private Button mBackButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mImageView = (ImageView)findViewById(R.id.imageView);
        mTextView = (TextView)findViewById(R.id.fact);
        mButton = (Button)findViewById(R.id.factButton);

        showRandomFact();

        mButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                showRandomFact();

            }
        });
    }

    public void showRandomFact() {
        shuffleFacts();
        mImageView.setImageResource(factArray[0].getmImage());
        mTextView.setText(factArray[0].getmFact());
    }


    Facts f01 = new Facts(R.drawable.sisiphys, "Matthais Pliessnieg is an artist who creates furniture in Brooklyn, NY.");
    Facts f02 = new Facts(R.drawable.sze, "Sarah Sze is an architect turned artist who works in Brooklyn, NY. Her installations are from another world but made with everyday objects. " +
            "Once you recognize something in her work you won't see it the same again.");
    Facts f03 = new Facts(R.drawable.kern, "Brett Kern creates candy coated ceramic sculptures. He is able to obtain a smooth " +
            "texture from pouring his sculptures into molds and then uses commercial glazes and very specific temperatures to achieve a exceptionally smooth effect.");
    Facts f04 = new Facts(R.drawable.stadia, "Julie Mehretu is highly influential female artist in the United States. " +
            "Her works are characterized by highly energized topographical maps, building blueprints and urban sprawl.");
    Facts f05 = new Facts(R.drawable.cindy, "Cindy Sherman is a photographer and one of the highest paid women in the visual arts. She is the first selfie queen. " +
            "Most of her work are portraits and stills of herself. She deconstructs and ostracizes the male gaze.");
    Facts f06 = new Facts(R.drawable.flamenco, "EV DAY is an installation artist. Her interests are creating powerful moments in space that are filled with anger, rage, lust, and excitement " +
            "Topics she likes to discuss are haute couture, feminism and identity.");
    Facts f07 = new Facts(R.drawable.ritchie, "Matthew Ritchie is a British and a classically trained artist. Interestingly he pulls influence from minimalism but his painterly forms have root in expressionism.");
    Facts f08 = new Facts(R.drawable.cremaster, "Matthew Barney was once an all star football player, Calvin Klein model and husband of singer Bjork. His work is captured through cinematography. " +
            "He focuses on images of masculinity, physical prowess through prosthetics, and illusions of grandeur." );
    Facts f09 = new Facts(R.drawable.currier, "Anne Currier is an art professor on the east coast.  " +
            "She is a ceramic artist that defies the usual tendencies of clay.  Her craft is meticulously refined. Her work appears machined and smooth and in a discipline that's rarely predictable is an exceptional task.  " );
    Facts f10 = new Facts(R.drawable.hesse, "Eva Hesse is a Post-Minimalism artist. Her work is characterized by hanging forms and the use of alternative materials at the time. " +
            "Her experimentation in different chemicals led to her untimely demise. However, in her last moments she was able to make it to her first museum exhibition in a wheelchair.  " );
    Facts f11 = new Facts(R.drawable.neto, "Ernesto Neto is a Brazilian artist who specializes in a full sensory experience. His work begs to be squeezed and squished and encapsulates the viewer. Bean bags have nothing on him.  " );
    Facts f12 = new Facts(R.drawable.saraceno, "Tomas Saraceno is an Argentinian artist. His background is in art, architecture and science. He pulls inspiration from spider webs and actively participates in Aerocene, " +
            "an artistic community that takes their art to the skies in a collaborative/ethical/fossil fuel free way.  " );
    Facts f13 = new Facts(R.drawable.hirst, "Damian Hirst is best know for his death series. That in which he displays dead animals as a form of high art. " +
            "His work is well received and has been supported by Saatchi, the Bruce Wayne of the art world.  " );
    Facts f14 = new Facts(R.drawable.bourgeois, "Louise Bourgeois was a heavy hitter of the Modernist art movement. She was prolific, and stood with the best of them.  She is best known for her spider series. The spiders reference her mother's " +
            "character - protective, spinning, weaving, and nurturing. Des Moines is home to one of these sculptures. " );
    Facts f15 = new Facts(R.drawable.kruger, "Barbara Kruger is an art professor for UCLA. Her background is in graphic design. If you have seen a black and white image with red barred helvetica font it was likely her work. All of her work is concept rich, " +
            "she loves to dance, or stomp on ideas of consumerism, power, sexuality and pronouns." );
    Facts f16 = new Facts(R.drawable.kuo, "Yih Wen Kuo is a ceramics professor at Northern Illinois University.  Kuo's discipline with clay has a very calm nature. He uses restrictive tendencies to create a magnetic appearance. His complete control over the gravity of the glaze indicates he is a master in his realm. " );
    Facts [] factArray = new Facts[] {
            f01, f02, f03, f04, f05, f06, f07, f08, f09, f10, f11, f12, f13, f14, f15, f16 };


    public void shuffleFacts(){
        Collections.shuffle(Arrays.asList(factArray));
    }


}
