
package com.example.artsmart;



public class Facts {
    private int mImage;
    private String mFact;

    public Facts(int mImage, String mFact){
        this.mImage=mImage;
        this.mFact=mFact;

    }
    public int getmImage() {
        return mImage;
    }
    public String getmFact() {
        return mFact;
    }

}
